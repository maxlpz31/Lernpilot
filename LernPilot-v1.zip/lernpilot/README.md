# LernPilot v1.0 – Lernkarten + Quiz

Kostenlose Dark-Mode-PWA für iPhone, Android und Desktop. Kein Build-Prozess und kein API-Schlüssel erforderlich.

## Funktionen
- Lernsets erstellen und löschen
- Lernkarten hinzufügen und umdrehen
- Multiple-Choice-Quiz aus Karten eines Lernsets (mindestens vier unterschiedliche Antworten)
- Quiz-Trefferquote und Übersicht
- Lokale Speicherung im Browser (localStorage)
- Offline-Nutzung nach dem ersten erfolgreichen Online-Aufruf
- Demo-Lernset „Biologie – Evolution“

## Lokal starten
`index.html` im Browser öffnen. Für vollständige PWA-Funktionen einen lokalen Webserver nutzen, z. B. mit installiertem Python im Projektordner:

```bash
python3 -m http.server 8000
```

Dann `http://localhost:8000` öffnen.

## Kostenlos mit GitHub Pages veröffentlichen
1. Auf github.com anmelden und ein **öffentliches** Repository erstellen, z. B. `lernpilot`.
2. Alle Dateien aus diesem Ordner **direkt ins Hauptverzeichnis** des Repositorys hochladen (nicht den ZIP-Ordner als Ganzes).
3. Repository → **Settings** → **Pages** → **Build and deployment** → Source: **Deploy from a branch** → Branch: **main**, Folder: **/(root)** → **Save**.
4. Nach der Veröffentlichung die angezeigte URL öffnen. Meist `https://BENUTZERNAME.github.io/lernpilot/`.
5. iPhone (Safari): Teilen → **Zum Home-Bildschirm**. Android (Chrome): Menü → **App installieren** bzw. **Zum Startbildschirm hinzufügen**.

## Wichtig
- Daten liegen **nur lokal im jeweiligen Browser**. Sie werden **nicht synchronisiert** und können beim Löschen von Browserdaten verloren gehen. Für echte Nutzer sollte später Export/Backup und eine Datenbank ergänzt werden.
- Die App enthält **noch keine KI** und **keine Bezahlfunktion**. Quiz-Antworten sind andere Kartenantworten und daher nicht immer sinnvolle Distraktoren.
- GitHub Pages hostet nur statische Dateien. Niemals geheime KI-API-Schlüssel in den JavaScript-Code schreiben.
- Nach Code-Updates kann der Service Worker kurz eine alte Version zwischenspeichern. Bei neuen Releases den CACHE-Namen in `sw.js` erhöhen.
- Vor öffentlicher Vermarktung Datenschutz, Impressum und ggf. Jugendschutz/Einwilligungen prüfen.
